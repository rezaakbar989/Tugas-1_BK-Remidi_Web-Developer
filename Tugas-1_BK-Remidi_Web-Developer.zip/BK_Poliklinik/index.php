<?php
session_start();

$muncul = false;
$arah = null;

if (isset($_SESSION['login'])) {
  $muncul = true;
  $arah = $_SESSION['akses'];
} elseif (isset($_SESSION['signup'])) { 
  $muncul = true;
  $arah = $_SESSION['akses'];
}
?>

<?php
$title = 'Poliklinik'
if ($timbul) :
  include_once './layouts/welcome.php';
else:
  include_once './layouts/welcome.php';
endif
?>
