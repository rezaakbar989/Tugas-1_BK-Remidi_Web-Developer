<?php
$base_admin = "http://" . $_SERVER['HTTP_HOST'] . "/bk-poliklinik/pages/admin";
$base_pasien = "http://" . $_SERVER['HTTP_HOST'] . "/bk-poliklinik/pages/pasien";
$base_dokter = "http://" . $_SERVER['HTTP_HOST'] . "/bk-poliklinik/pages/dokter";
